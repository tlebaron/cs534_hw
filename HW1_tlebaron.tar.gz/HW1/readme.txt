Le Baron Thomas
HW1 CS534
01/28/2019

The homework folder is composed of:
- search.py: search script in python to complete the homework
- readme.txt: present file
- graph.txt.
- out_graph.txt: output of the search run on the graph.txt file.
- second_graph.txt.
- out_second_graph.txt: output of the search run on the second_graph.txt file.
- BonusProblem.txt: input file containing a graph to complete the conus problem (each search method gives a different list of expanded node)
- out_BonusProblem.txt: output of the search run on the BonusProblem.txt file.

Language
Python 2.7

Tested on
Python 2.7.12

Run the script
In the command line, to run the script on the "graph.txt file", execute: python search.py graph.txt
